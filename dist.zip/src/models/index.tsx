export interface ITheme {
  iconsColor: string;
}
