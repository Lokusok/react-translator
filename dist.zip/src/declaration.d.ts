declare module '*.css';

declare module '*.jpg';
declare module '*.jpeg';
declare module '*.png';
declare module '*.webp';
declare module '*.avif';
declare module '*.gif';
